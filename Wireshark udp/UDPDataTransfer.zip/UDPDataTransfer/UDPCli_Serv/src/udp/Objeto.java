package udp;

public class Objeto implements java.io.Serializable {
	private static final long serialVersionUID = 1L;
	int numeroSecuencia;
	long marcaTiempo;
	int cantObjetos;
	public Objeto(int numeroSecuencia, int cantObjetos){
		this.numeroSecuencia = numeroSecuencia;
		marcaTiempo = System.currentTimeMillis();
		this.cantObjetos = cantObjetos;
	}
}
