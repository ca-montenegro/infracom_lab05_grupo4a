package udp;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.Scanner;


public class Client {
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Ingrese la dirección IP del servidor:");
		String nombreHost = sc.nextLine();
		System.out.println("Ingrese el puerto en el que escucha y recibe el servidor:");
		int puerto = sc.nextInt();
		System.out.println("Ingrese el número de objetos a generar y enviar");
		int numeroObjetos = sc.nextInt();
		
		DatagramSocket socket;
		
		try {
			socket = new DatagramSocket();
			InetAddress host = InetAddress.getByName(nombreHost);

			for (int i=0; i<numeroObjetos; i++){
				ByteArrayOutputStream bos = new ByteArrayOutputStream();
				ObjectOutput out = null;
				Objeto o = new Objeto(i+1, numeroObjetos);
				out = new ObjectOutputStream(bos);   
				out.writeObject(o);
				out.flush();
				byte[] bytes = bos.toByteArray();
				DatagramPacket packet = new DatagramPacket(bytes, bytes.length, host, puerto);
				socket.send(packet);
			}

		} catch (SocketException e) {
			e.printStackTrace();
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
}
