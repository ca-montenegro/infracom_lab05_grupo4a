package udp;
import java.io.ByteArrayInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.HashMap;


public class Server {
	static HashMap<String, Cliente> clientes;
	public static void main(String[] args) {
	clientes = new HashMap<>();
	clientes.clear();
		try{
			DatagramSocket socket = new DatagramSocket(Integer.parseInt(args[0]));
			byte[] buffer = new byte[1024];
			while (true){
				DatagramPacket req = new DatagramPacket(buffer, buffer.length);
				socket.receive(req);
				
				ByteArrayInputStream bis = new ByteArrayInputStream(req.getData());
				ObjectInput in = null;
				in = new ObjectInputStream(bis);
				Objeto o = null;
				try {
					o = (Objeto) in.readObject();
				} catch (ClassNotFoundException e) {
					e.printStackTrace();
				}
				actualizarCliente(req.getAddress().getHostAddress(), o);
			}
		}
		catch (SocketException e){
			e.printStackTrace();
		}
		catch(IOException e){
			e.printStackTrace();
		}
	}
	
	static void actualizarCliente(String ipCliente, Objeto o){
		Cliente c = clientes.getOrDefault(ipCliente, new Cliente());
		c.actualizarPromedio(System.currentTimeMillis()-o.marcaTiempo);
		c.objetosRecibidos++;
		c.objetosTotales=o.cantObjetos;
		clientes.put(ipCliente, c);
		try
		{
		    String filename= "../logs/ip"+ipCliente+".txt";
		    FileWriter fw = new FileWriter(filename,true);
		    fw.write(o.numeroSecuencia+": " + (System.currentTimeMillis()-o.marcaTiempo)+ " ms.  Tiempo promedio:"  + c.tPromedio + " ms.  Objetos recibidos: " + c.objetosRecibidos + " de " + c.objetosTotales);
		    fw.write(System.getProperty( "line.separator" ));
		    fw.close();
		}
		catch(IOException ioe)
		{
		    System.err.println("IOException: " + ioe.getMessage());
		}
	}
	
	static class Cliente {
		double tPromedio;
		int objetosRecibidos;
		int objetosTotales;
		
		public Cliente(){
			tPromedio=0;
			objetosRecibidos=0;
			objetosTotales=0;
		}
		public void actualizarPromedio(long t){
			tPromedio = (double)((tPromedio*objetosRecibidos+t)/(objetosRecibidos+1));
		}
		public double getTPromedio(){
			return tPromedio;
		}
		public int getObjetosRecibidos(){
			return objetosRecibidos;
		}
	}
}
