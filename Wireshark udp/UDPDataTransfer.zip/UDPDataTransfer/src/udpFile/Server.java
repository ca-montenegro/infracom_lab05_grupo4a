package udpFile;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.security.MessageDigest;

public class Server {

	public static void main(String[] args) {
		String pathFile = args[0];
		try {
			DatagramSocket serverSocket = new DatagramSocket(4000);
			int packetsize=1024;
			FileOutputStream fos = null;
			fos = new FileOutputStream(pathFile);
			MessageDigest md = MessageDigest.getInstance("MD5");
			BufferedOutputStream bos = new BufferedOutputStream(fos);
			double nosofpackets=Math.ceil(((int) (new File(pathFile)).length())/packetsize);
			byte[] mybytearray = new byte[packetsize];
			DatagramPacket receivePacket = new DatagramPacket(mybytearray,mybytearray.length);

			System.out.println(nosofpackets+" "+mybytearray+" "+ packetsize);

			for(double i=0;i<nosofpackets+1;i++)
			{

				serverSocket.receive(receivePacket); 
				byte audioData[] = receivePacket.getData();
				System.out.println("Packet:"+(i+1));
				bos.write(audioData, 0,audioData.length);
			}
			
			byte[] thedigest = md.digest();
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
}
